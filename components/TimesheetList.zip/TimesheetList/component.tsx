import React, { useState } from "react";
import { useSuperblocksContext, useSuperblocksIsLoading } from "@superblocksteam/custom-components";
import { type Props, type EventTriggers } from "./types";
import "./main.scss";

export default function TimesheetComponent({ currentTimesheets, currentWeek, projectsList }: Props) {
  console.log("Props - currentTimesheets:", currentTimesheets);
  console.log("Props - currentWeek:", currentWeek);
  console.log("Props - projectsList:", projectsList);

  const isLoading = useSuperblocksIsLoading();
  const {
    updateProperties,
    events: { onChangeTimesheet },
  } = useSuperblocksContext<Props, EventTriggers>();
  const weekdays_columns = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];

  const [timesheets, setTimesheets] = useState(currentTimesheets || []);

  //useEffect enables the timesheets and setTimesheets variables to dynamiclly react to currentTimesheets fetching data
  React.useEffect(() => {
    if (currentTimesheets && currentTimesheets.length > 0) {
      console.log("currentTimesheets updated:", currentTimesheets);
      setTimesheets(currentTimesheets);
    }
  }, [currentTimesheets]);

  //Logging
  console.log("After initialization:",timesheets, setTimesheets);

  const handleHoursChange = (
    projectIndex: number,
    day: string,
    hours: number
  ) => {
    const updatedTimesheets = [...timesheets];
    updatedTimesheets[projectIndex][day] = hours;
    updatedTimesheets[projectIndex].totalHours = weekdays_columns.reduce(
      (sum, day) => sum + (updatedTimesheets[projectIndex][day] || 0),
      0
    );
    setTimesheets(updatedTimesheets);
    onChangeTimesheet({
      project: updatedTimesheets[projectIndex].project_name,
      task: null,
      day,
      hours,
    });
  };

  const handleInputChange = (projectIndex: number, field: string, value: any) => {
    const updatedTimesheets = [...timesheets];
    updatedTimesheets[projectIndex][field] = value;
    setTimesheets(updatedTimesheets);
  };

  const addNewRow = () => {
    const newRow = {
      project_name: "",
      location: "",
      billable: false,
      task: "",
      mon: 0,
      tue: 0,
      wed: 0,
      thu: 0,
      fri: 0,
      sat: 0,
      sun: 0,
      totalHours: 0,
    };
    setTimesheets([...timesheets, newRow]);
  };

  return (
    <div
      style={{
        height: "100%",
        width: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "stretch",
        justifyContent: "stretch",
        boxSizing: "border-box",
        border: "10px",
        borderColor: "#2f3437",
      }}
    >
      {isLoading ? <div>Loading...</div> : ""}
      {!isLoading && (
        <div
          style={{
            backgroundColor: "#1c1f21",
            borderRadius: "4px",
            padding: "20px",
            width: "100%",
            height: "100%",
            overflow: "auto",
            boxSizing: "border-box",
            boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
            border: "4px",
            borderColor: "#2f3437",
          }}
        >
          {timesheets.length > 0 ? (
            <>
              <table
                style={{
                  width: "100%",
                  borderCollapse: "collapse",
                  textAlign: "left",
                  fontSize: "14px",
                }}
              >
                <thead>
                  <tr>
                    <th className="headerStyle">Project</th>
                    <th className="headerStyle">Location</th>
                    <th className="headerStyle">Billable</th>
                    <th className="headerStyle">Task</th>
                    {weekdays_columns.map((day) => (
                      <th className="headerStyle" key={day}>
                        {day.toUpperCase()}
                      </th>
                    ))}
                    <th className="headerStyle">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {timesheets.map((timesheet: any, timesheetIndex: number) => (
                    <tr key={timesheetIndex}>
                      <td className="cellStyle">
                        <input
                          type="text"
                          value={timesheet.project_name}
                          onChange={(e) =>
                            handleInputChange(timesheetIndex, "project_name", e.target.value)
                          }
                        />
                      </td>
                      <td className="cellStyle">
                        <input
                          type="text"
                          value={timesheet.location || "N/A"}
                          onChange={(e) =>
                            handleInputChange(timesheetIndex, "location", e.target.value)
                          }
                        />
                      </td>
                      <td className="cellStyle">
                        <input
                          type="checkbox"
                          checked={timesheet.billable}
                          onChange={(e) =>
                            handleInputChange(timesheetIndex, "billable", e.target.checked)
                          }
                        />
                      </td>
                      <td className="cellStyle">
                        <textarea
                          value={timesheet.task || ""}
                          onChange={(e) =>
                            handleInputChange(timesheetIndex, "task", e.target.value)
                          }
                          rows={2}
                          cols={20}
                        />
                      </td>
                      {weekdays_columns.map((day) => (
                        <td className="cellStyle" key={day}>
                          <input
                            type="number"
                            min="0"
                            value={timesheet[day] || 0}
                            onChange={(e) =>
                              handleHoursChange(timesheetIndex, day, +e.target.value)
                            }
                            style={{
                              width: "50px",
                              textAlign: "center",
                              border: "1px solid #ccc",
                              borderRadius: "4px",
                            }}
                          />
                        </td>
                      ))}
                      <td className="cellStyle">{timesheet.totalHours || 0}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <button
                onClick={addNewRow}
                style={{
                  marginTop: "10px",
                  padding: "10px 20px",
                  borderRadius: "4px",
                  backgroundColor: "#007bff",
                  color: "#fff",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                Add New Row
              </button>
            </>
          ) : (
            <p style={{ color: "#333" }}>No timesheets available at the moment.</p>
          )}
        </div>
      )}
    </div>
  );
}

